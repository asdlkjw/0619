package com.example.vo;

public class ItemVO {
	private int itemno =0 ;
	private String itemname = null;
	private int itemprice = 0;
	private int itemqty = 0;
	private String itemdes = null;
	private String itemdate = null;
	public int getItemno() {
		return itemno;
	}
	public void setItemno(int itemno) {
		this.itemno = itemno;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public int getItemprice() {
		return itemprice;
	}
	public void setItemprice(int itemprice) {
		this.itemprice = itemprice;
	}
	public int getItemqty() {
		return itemqty;
	}
	public void setItemqty(int itemqty) {
		this.itemqty = itemqty;
	}
	public String getItemdes() {
		return itemdes;
	}
	public void setItemdes(String itemdes) {
		this.itemdes = itemdes;
	}
	public String getItemdate() {
		return itemdate;
	}
	public void setItemdate(String itemdate) {
		this.itemdate = itemdate;
	}
	
}
